# ETERNELLE — Native Android AR Birthday Experience

A native Android application for Shiba Sis, built with Kotlin, Jetpack Compose, Google ARCore and SceneView. This is **not a website or WebAR wrapper**.

## Included in this source project
- Native Android launcher experience.
- ARCore camera session and horizontal plane detection.
- Automatic placement of a custom 3D rose-quartz heart/constellation sculpture on a detected floor or table.
- Original locally bundled ambient soundscape.
- Jamshedpur–Kolkata dedication and final brotherly message.
- Local GLB model asset; no remote 3D model hosting at runtime.

## Build the APK
1. Install Android Studio and Android SDK Platform 36.
2. Install JDK 17 (Android Studio's bundled JBR is suitable if it is JDK 17).
3. Open this folder (`ETERNELLE_Native_AR`) in Android Studio.
4. Allow Gradle sync to download dependencies.
5. Connect an ARCore-compatible Android phone, enable USB debugging, then Run.
6. To create an installable debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio outputs it under `app/build/outputs/apk/debug/app-debug.apk`.

Command line after Gradle is installed:
`gradle :app:assembleDebug`

## Device requirements
- Android 7.0 (API 24) or later.
- ARCore-supported device.
- Google Play Services for AR installed/updated.
- Camera permission.
- Good lighting and a visible horizontal floor/table for initial plane detection.

ARCore Required is declared in the manifest, so unsupported devices cannot use this AR app. Check the supported-device list before installation:
https://developers.google.com/ar/devices

## Project toolchain
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Kotlin 2.2.21
- JDK 17 / JVM target 17
- compileSdk 36 / minSdk 24
- SceneView AR 4.18.0 (the SceneView release line documented for AGP 8, compileSdk 36, Kotlin 2.2 and JVM 17 compatibility).

## Current prototype scope
- AR places the custom sculpture automatically on the first detected upward-facing plane. It does not yet support drag-to-reposition.
- The reveal is a native in-app text/visual moment; no external narrator recording is included.
- Soundscape is an original synthesised ambient bed, not a commercial track.
- This source project has not been compiled or device-tested in this environment. The current runtime did not have Android SDK / Gradle installed, so no APK binary is claimed or attached.
- Before gifting, build and test on Shiba's exact phone. Camera/AR support varies by model.


## Build an APK automatically with GitHub Actions

This project now includes `.github/workflows/android-apk.yml`.

1. Create a **private** GitHub repository.
2. Upload the contents of this project folder to the repository root (the `ETERNELLE_Native_AR` folder contents, not the parent folder).
3. Push to the `main` branch, or open Actions and run **Build ETERNELLE Android APK** manually.
4. When the workflow succeeds, open its run and download the `ETERNELLE-debug-apk` artifact.
5. Extract the artifact to get `app-debug.apk`.

The workflow builds a debug APK. It is suitable for testing/sideloading, not Play Store publication. A release APK should be separately signed with a private signing key.

This chat environment does not include the Android SDK/Gradle build toolchain, so the APK has not been compiled or verified here. The GitHub Actions workflow is provided to perform the build in a hosted Android build environment after the project is pushed to a repository.
