package com.eternelle.shiba

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.ar.core.Anchor
import com.google.ar.core.Plane
import io.github.sceneview.ar.ARSceneView
import io.github.sceneview.ar.arcore.createAnchorOrNull
import io.github.sceneview.ar.arcore.getUpdatedPlanes
import io.github.sceneview.ar.node.AnchorNode
import io.github.sceneview.rememberModelInstance

private val Midnight = Color(0xFF17152D)
private val Rose = Color(0xFFFFC2D1)
private val Gold = Color(0xFFFFE6AE)
private val Lavender = Color(0xFFD7CAFF)
private val SoftWhite = Color(0xFFFFF8F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(23, 21, 45)
        window.navigationBarColor = android.graphics.Color.rgb(23, 21, 45)
        setContent { EternelleApp() }
    }
}

@Composable
private fun EternelleApp() {
    var started by remember { mutableStateOf(false) }
    var anchor by remember { mutableStateOf<Anchor?>(null) }
    var finalReveal by remember { mutableStateOf(false) }
    var soundOn by remember { mutableStateOf(false) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var tracking by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val latestPlayer by rememberUpdatedState(mediaPlayer)
    val latestAnchor by rememberUpdatedState(anchor)
    DisposableEffect(Unit) {
        onDispose {
            latestPlayer?.run {
                try { stop() } catch (_: Exception) {}
                release()
            }
            latestAnchor?.detach()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Midnight, Color(0xFF29203F), Midnight))
        )
    ) {
        if (started) {
            ARSceneView(
                modifier = Modifier.fillMaxSize(),
                planeRenderer = true,
                onSessionUpdated = { _, frame ->
                    if (anchor == null) {
                        val plane = frame.getUpdatedPlanes()
                            .firstOrNull {
                                it.type == Plane.Type.HORIZONTAL_UPWARD_FACING &&
                                it.trackingState == com.google.ar.core.TrackingState.TRACKING
                            }
                        if (plane != null) {
                            anchor = plane.createAnchorOrNull(plane.centerPose)
                            tracking = anchor != null
                        }
                    }
                },
            ) {
                val heartUniverse = rememberModelInstance(modelLoader, "models/eternelle_heart_universe.glb")
                anchor?.let { placedAnchor ->
                    AnchorNode(anchor = placedAnchor) {
                        heartUniverse?.let { model ->
                            ModelNode(modelInstance = model, scaleToUnits = 1.45f, autoAnimate = false)
                        }
                    }
                }
            }

            // Native overlay: the camera/AR scene remains full-screen underneath.
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "ETERNELLE  ·  04 DECEMBER 2026",
                        color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                        letterSpacing = 2.4.sp
                    )
                    Spacer(Modifier.height(9.dp))
                    Text(
                        if (finalReveal) "A little universe. A lifetime of love." else "Find a little space for magic",
                        color = SoftWhite, fontSize = 16.sp, textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        color = Midnight.copy(alpha = 0.84f),
                        shape = RoundedCornerShape(22.dp),
                        tonalElevation = 8.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 17.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                when {
                                    finalReveal -> "FROM JAMSHEDPUR, WITH LOVE"
                                    tracking -> "YOUR UNIVERSE IS HERE ✦"
                                    else -> "SLOWLY MOVE YOUR PHONE"
                                },
                                color = Gold, fontSize = 10.sp, letterSpacing = 1.8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                when {
                                    finalReveal -> "Kolkata may be where your days are unfolding, but Jamshedpur will always hold a little piece of home for you."
                                    tracking -> "A heart made of starlight is waiting on your floor or table. Look around it, then tap the reveal."
                                    else -> "Point towards the floor or a table. Let ARCore discover a surface and place the birthday universe."
                                },
                                color = SoftWhite, fontSize = 13.sp, lineHeight = 19.sp,
                                textAlign = TextAlign.Center
                            )
                            if (finalReveal) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "“Tera veer hamesha tere naal hai.”",
                                    color = Rose, fontSize = 17.sp, fontStyle = FontStyle.Italic,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NativePillButton(
                            label = if (soundOn) "Sound off ♫" else "Sound on ♫",
                            secondary = true,
                            onClick = {
                                if (!soundOn) {
                                    if (mediaPlayer == null) {
                                        mediaPlayer = MediaPlayer.create(context, R.raw.eternelle_soundscape)
                                        mediaPlayer?.isLooping = true
                                    }
                                    mediaPlayer?.start()
                                    soundOn = true
                                } else {
                                    mediaPlayer?.pause()
                                    soundOn = false
                                }
                            }
                        )
                        NativePillButton(
                            label = if (finalReveal) "Back to AR" else "Reveal love ✦",
                            secondary = false,
                            onClick = { finalReveal = !finalReveal }
                        )
                    }
                    Spacer(Modifier.height(7.dp))
                    Text(
                        if (anchor == null) "AR surface detection · Keep moving gently" else "Move around the sculpture to see it from every angle",
                        color = Color.White.copy(alpha = .82f), fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Native app opening screen (not a web page).
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("A ONE-OF-ONE BIRTHDAY EXPERIENCE", color = Gold, fontSize = 10.sp, letterSpacing = 2.2.sp)
                Spacer(Modifier.height(28.dp))
                Text("ETERNELLE", color = SoftWhite, fontSize = 17.sp, letterSpacing = 8.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.height(8.dp))
                Text("Shiba Sis.", color = Rose, fontSize = 54.sp, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center)
                Spacer(Modifier.height(22.dp))
                Text(
                    "Some surprises are too lovely to stay on a screen.\n\nThis one is made of starlight, music and a brother's love.",
                    color = SoftWhite.copy(alpha = .9f), fontSize = 15.sp, lineHeight = 24.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(36.dp))
                NativePillButton("Enter her universe ✦", false) { started = true }
                Spacer(Modifier.height(20.dp))
                Text("4 DECEMBER 2026  ·  FROM JAMSHEDPUR, WITH LOVE", color = Lavender, fontSize = 9.sp, letterSpacing = 1.2.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(34.dp))
                Text("Requires an ARCore-compatible Android phone.", color = Color.White.copy(alpha = .55f), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun NativePillButton(label: String, secondary: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (secondary) Color(0xCC342944) else Rose,
            contentColor = if (secondary) SoftWhite else Midnight
        ),
        contentPadding = PaddingValues(horizontal = 19.dp, vertical = 11.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
    }
}
